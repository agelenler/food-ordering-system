package com.food.ordering.system.payment.service.dataaccess.credithistory.exception;

public class CreditHistoryDataaccessException extends RuntimeException {

    public CreditHistoryDataaccessException(String message) {
        super(message);
    }
}
