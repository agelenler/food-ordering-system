package com.food.ordering.system.customer.service.dataaccess.customer.exception;

public class CustomerDataaccessException extends RuntimeException {

    public CustomerDataaccessException(String message) {
        super(message);
    }
}
